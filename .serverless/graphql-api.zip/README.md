### 🕸📞 📇 GraphQL talking to DynamoDB
GraphQL + NoSQL boilerplate in Node on AWS
Alex Jacks, 2019, MIT
## [https://github.com/alexanderjacks/graphql-dynamo](https://github.com/alexanderjacks/graphql-dynamo)